const settings = {
  packname: 'TEDDY-XMD',
  author: '‎',
  botName: "TEDDY-XMD",
  botOwner: 'Teddy', // Your name
  ownerNumber: '254799963583', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.5.9",
  updateZipUrl: "https://github.com/Teddytech1/TEDDY-XMD/archive/refs/heads/main.zip",
};

module.exports = settings;
